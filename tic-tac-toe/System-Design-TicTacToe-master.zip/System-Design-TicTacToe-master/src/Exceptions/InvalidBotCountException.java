package Exceptions;

public class InvalidBotCountException extends Exception {
    public InvalidBotCountException(String message) {
        super(message);
    }
}
