package Exceptions;

public class SameSymbolException extends Exception {
    public SameSymbolException(String message) {
        super(message);
    }
}
