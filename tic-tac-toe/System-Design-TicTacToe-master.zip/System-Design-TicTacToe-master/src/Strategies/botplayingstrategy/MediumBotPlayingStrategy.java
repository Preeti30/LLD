package Strategies.botplayingstrategy;

import Models.Board;
import Models.Move;

public class MediumBotPlayingStrategy implements BotPlayingStrategy {
    @Override
    public Move makeMove(Board board) {
        return null;
    }
}
