package Models;

public enum BotDifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
