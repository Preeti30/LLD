package Models;

public enum CellState {
    EMPTY,
    FILLED
}
