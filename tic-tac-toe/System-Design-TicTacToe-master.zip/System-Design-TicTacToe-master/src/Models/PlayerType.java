package Models;

public enum PlayerType {
    HUMAN,
    BOT
}
