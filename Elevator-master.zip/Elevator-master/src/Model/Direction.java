package Model;

public enum Direction {
    UP, DOWN
}
