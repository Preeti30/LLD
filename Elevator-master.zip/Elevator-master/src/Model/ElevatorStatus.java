package Model;

public enum ElevatorStatus {

    IDLE, RUNNING;
}
