package Model;

import java.util.List;

public class InternalButtonDispatcher {

    List<ElevatorController> elevatorControllerList;

    public void submitRequest(int destination, Elevator elevator) {


    }
}
